
// Self Invoking function
(function(){
	
	// UserData Object storing member variable
	var UserData = {
		fname : "",
		lname : "",
		address : "",
		email : "",
		age : 0,
		phneno : ""
	};
	
	var storeData = {
		saveItem : function(){
			var isCount = localStorage.length;
			var formData = document.getElementsByClassName("form-control");
			UserData.fname = formData[0].value;
			UserData.lname = formData[1].value;
			UserData.address = formData[2].value;
			UserData.email = formData[3].value;
			UserData.age = formData[4].value;
			UserData.phneno = formData[5].value;
			
			// Only valididate the input fields are empty or not
			if(UserData.fname == null || UserData.lname == ""){
				//alert("Please Enter First Name");
				return false;
			}
			else if(UserData.lname == null || UserData.lname == ""){
				//alert("Please Enter Last Name");
				return false;
			}
			else if(UserData.address == null || UserData.address == ""){
				//alert("Please Enter Address");
				return false;
			}
			else if(UserData.email == null || UserData.email == ""){
				//alert("Please Enter Email Address");
				return false;
			}
			else if(UserData.age == null || UserData.age == ""){
				//alert("Please Enter Age");
				return false;
			}
			else if(UserData.phneno == null || UserData.phneno == ""){
				//alert("Please Enter Phone Number");
				return false;
			}				
			// Store data in localStorage
			localStorage.setItem("UserData_" + isCount, JSON.stringify(UserData));
			// Page reload
			location.reload();
			
		},
		loadItem : function(){
			var datacount = localStorage.length;
			if (datacount > 0){
				var render = "<table class='table table-bordered'>";
				render += "<tr><th>Sl.No.</th><th>First Name</th><th>Last Name</th><th>Address</th>" + 
                          "<th>Email</th><th>Age</th><th>Phone Number</th><th>Edit Data</th></tr>";
						  
                    for (i=0; i < datacount; i++) { 
                        var key = localStorage.key(i); 
                        var userData = localStorage.getItem(key); 
                        var data = JSON.parse(userData); // Parse JSON data to retrieve the data elements
                        render+="<tr><td>"+Number(i+1)+"</td>";
                        render += "<td>" + data.fname + "</td><td>" + data.lname + "</td>";
                        render += "<td>" + data.address + "</td>";
                        render += "<td>" + data.email + "</td>";
                        render += "<td>" + data.age + "</td>";
						render += "<td>" + data.phneno + "</td>";
                        render +=  "<td> <button type='button' class='btn btn-primary btn-md edit_button'                                          data-toggle='modal' data-target='#myModal' data-fname='"+data.fname+"' data-lname='"+data.lname+"' data-address='"+data.address+"'  data-email='"+data.email+"' data-age='"+data.age+"' data-phneno='"+data.phneno+"' data-id='"+Number(i+1)+"'>Edit</button></td>";
                    }
                    render += "</table>";
                    var newTable = document.getElementById("divContainer");
                    newTable.innerHTML = render;
			}
		}
	}
	window.onload = function() {
	storeData.loadItem(); //at first, loading the existing data in localStorage to the front end table 
	var btnsubmit = document.getElementById('btnsubmit');
	btnsubmit.addEventListener('click', storeData.saveItem);// attaching the saveItem function to the Submit button. Onclick of Submit, saveItem() is executed
	};	
})();


$(document).on( "click", '.edit_button',function(e) {
  
	var id = $(this).data('id');
	var fname = $(this).data('fname');
	// alert("fname = "+fname);
	var lname =  $(this).data('lname');
	// alert("lname = "+lname);
	var address =  $(this).data('address');
	// alert("address = "+address);
	var email = $(this).data('email');
	// alert("lname = "+lname);	
	var age =  $(this).data('age');
	// alert("age = "+age);
	var phneno = $(this).data('phneno');
	// alert("phneno ="+phneno);

	$(".modal-id").val(id);
	$(".modal-fname").val(fname);
	$(".modal-lname").val(lname);
	$(".modal-address").val(address);
	$(".modal-email").val(email);
	$(".modal-age").val(age);
	$(".modal-phneno").val(phneno);

	$('#save').click(function () {
	// when the submit button in the modal is clicked, form is submitted 
	alert('Submitting Form Data');
	$('#userEntry').submit();
	localStorage.clear();
    });      

});